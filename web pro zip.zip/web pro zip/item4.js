const foodItem= [
    {
    id: 1,
    name: 'full home cleaning',
    category : 'Cleaning',
    rating : 4.75,
    price: 5499,
    img: 'imgs/cleaningpage/pic1.webp',
    quantity: 1
},
{
    id: 2,
    name: 'Kitchen Cleaning',
    category : 'Cleaning',
    rating : 4.73,
    price: 1999,
    img: 'imgs/cleaningpage/pic2.webp',
    quantity: 1
},
{
    id: 3,
    name: ' Bathroom cleaning',
    category : 'Cleaning',
    rating : 4.78,
    price: 599,
    img: 'imgs/cleaningpage/pic3.webp',
    quantity: 1
},
{
    id: 4,
    name: '2 cupbards wetwiping',
    category : 'Cleaning',
    rating : 4.81,
    price: 299,
    img: 'imgs/cleaningpage/pic4.webp',
    quantity: 1
},
{
    id: 10,
    name: 'Kitchen with Utensil Removal',
    category : 'Pestcontrol',
    rating : 4.84,
    price: 1098,
    img: 'imgs/cleaningpage/pic5.webp',
    quantity: 1
},
{
    id: 11,
    name: 'Utensils Removal Service',
    category : 'Pestcontrol',
    rating : 4.84,
    price: 199,
    img: 'imgs/cleaningpage/pic6.webp',
    quantity: 1
},
{
    id: 12,
    name: 'Offices Pest Control',
    category : 'Pestcontrol',
    rating : 4.70,
    price: 1449,
    img: 'imgs/cleaningpage/pic7.webp',
    quantity: 1
},
{
    id: 13,
    name: 'Home pest control',
    category : 'Pestcontrol',
    rating : 4.88,
    price: 1999,
    img: 'imgs/cleaningpage/pic8.webp',
    quantity: 1
},
]
export {foodItem};