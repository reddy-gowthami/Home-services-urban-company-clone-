const foodItem= [
    {
    id: 1,
    name: '4 walls',
    category : 'Wall',
    rating : 4.84,
    price: 1999,
    img: 'imgs/paintingpage/pic1.jpg',
    quantity: 1
},
{
    id: 2,
    name: 'singal wall',
    category : 'Wall',
    rating : 4.83,
    price: 499,
    img: 'imgs/paintingpage/pic2.avif',
    quantity: 1
},
{
    id: 3,
    name: 'custom wall painting',
    category : 'Wall',
    rating : 4.82,
    price: 899,
    img: 'imgs/paintingpage/pic3.jpg',
    quantity: 1
},
{
    id: 4,
    name: 'white paint',
    category : 'Wall',
    rating : 4.87,
    price: 299,
    img: 'imgs/paintingpage/pic4.jpg',
    quantity: 1
},
{
    id: 10,
    name: 'Duplex',
    category : 'Home',
    rating : 4.80,
    price: 50000,
    img: 'imgs/paintingpage/pic5.jpg',
    quantity: 1
},
{
    id: 11,
    name: 'custom home painting',
    category : 'Home',
    rating : 4.80,
    price: 3000,
    img: 'imgs/paintingpage/pic6.jpg',
    quantity: 1
},
{
    id: 12,
    name: 'single floor',
    category : 'Home',
    rating : 4.80,
    price: 15000,
    img: 'imgs/paintingpage/pic7.jpg',
    quantity: 1
},
{
    id: 13,
    name: 'celling',
    category : 'Home',
    rating : 4.81,
    price: 5000,
    img: 'imgs/paintingpage/pic8.jpg',
    quantity: 1
},
]
export {foodItem};