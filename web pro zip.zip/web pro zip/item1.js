const foodItem= [
    {
    id: 1,
    name: 'Underarms waxing',
    category : 'Waxing',
    rating : 4.84,
    price: 309,
    img: 'imgs/womensalonpage/waxing/pic2.webp',
    quantity: 1
},
{
    id: 2,
    name: 'Full legs waxing',
    category : 'Waxing',
    rating : 4.85,
    price: 359,
    img: 'imgs/womensalonpage/waxing/pic3.webp',
    quantity: 1
},
{
    id: 3,
    name: 'Half arm waxing',
    category : 'Waxing',
    rating : 4.83,
    price: 199,
    img: 'imgs/womensalonpage/waxing/pic4.webp',
    quantity: 1
},
{
    id: 4,
    name: 'Back waxing',
    category : 'Waxing',
    rating : 4.87,
    price: 449,
    img: 'imgs/womensalonpage/waxing/pic5.webp',
    quantity: 1
},
{
    id: 5,
    name: 'Stomach waxing',
    category : 'Waxing',
    rating : 4.87,
    price: 299,
    img: 'imgs/womensalonpage/waxing/pic6.webp',
    quantity: 1
},
{
    id: 10,
    name: 'Threading',
    category : 'Facialscleanups',
    rating : 4.84,
    price: 49,
    img: 'imgs/womensalonpage/Facials&cleanups/pic1.webp',
    quantity: 1
},
{
    id: 11,
    name: 'Face waxing',
    category : 'Facialscleanups',
    rating : 4.89,
    price: 109,
    img: 'imgs/womensalonpage/Facials&cleanups/pic2.webp',
    quantity: 1
},
{
    id: 12,
    name: 'Bleach for face',
    category : 'Facialscleanups',
    rating : 4.83,
    price: 559,
    img: 'imgs/womensalonpage/Facials&cleanups/pic3.webp',
    quantity: 1
},
{
    id: 13,
    name: 'Detan',
    category : 'Facialscleanups',
    rating : 4.83,
    price: 449,
    img: 'imgs/womensalonpage/Facials&cleanups/pic4.webp',
    quantity: 1
},
{
    id: 14,
    name: 'Bleach for face,neck',
    category : 'Facialscleanups',
    rating : 4.84,
    price: 799,
    img: 'imgs/womensalonpage/Facials&cleanups/pic5.jpg',
    quantity: 1
},
{
    id: 16,
    name: 'British Rose pedicure',
    category : 'Pedicure',
    rating : 4.83,
    price: 759,
    img: 'imgs/womensalonpage/Pedicure/pic1.webp',
    quantity: 1

},
{
    id: 17,
    name: 'Foot massage',
    category : 'Pedicure',
    rating : 4.82,
    price: 200,
    img: 'imgs/womensalonpage/Pedicure/pic2.webp',
    quantity: 1
},
{
    id: 18,
    name: 'Cut, file & polish',
    category : 'Pedicure',
    rating : 4.82,
    price: 199,
    img: 'imgs/womensalonpage/Pedicure/pic3.webp',
    quantity: 1

},
{
    id: 23,
    name: 'Head massage',
    category : 'Haircare',
    rating : 4.83,
    price: 349,
    img: 'imgs/womensalonpage/Haircare/pic1.webp',
    quantity: 1
},
{
    id: 24,
    name: 'Hair colour/mehendi',
    category : 'Haircare',
    rating : 4.81,
    price: 299,
    img: 'imgs/womensalonpage/Haircare/pic2.webp',
    quantity: 1
},
{
    id: 25,
    name: 'Headmassage-10mins',
    category : 'Haircare',
    rating : 4.85,
    price: 200,
    img: 'imgs/womensalonpage/Haircare/pic3.webp',
    quantity: 1
},
{
    id: 26,
    name: 'Loreal Hair Spa',
    category : 'Haircare',
    rating : 4.76,
    price: 1249,
    img: 'imgs/womensalonpage/Haircare/pic4.webp',
    quantity: 1
},
]
export {foodItem};